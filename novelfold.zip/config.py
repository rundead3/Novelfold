
def get_archive_pdb_path(genNo):
    return "C:\\Users\\Rundead\\Novelfold\\Archive\\pdbs\\gen"+str(genNo)

def get_archive_fasta_path(genNo):
    return "C:\\Users\\Rundead\\Novelfold\\Archive\\fastas\\archive"+str(genNo)

def get_new_fastas_path():
    return "C:\\Users\\Rundead\\Omegafold\\randseq.txt"

def get_blobulator_path():
    return "C:\\Users\\Rundead\\Omegaforl\\blobulator-main"

def get_pdbs_path():
    return "C:\\Users\\Rundead\\Omegaforl\\res1\\"

def get_dssp_output_path():
    return "C:\\Users\\Rundead\\Omegaforl\\res1\\dssps.txt"

def get_omegafold_path():
    return "C:\\Users\\Rundead\\OmegaFold"

def get_dssp_path():
    return "C:\\Users\\Rundead\\Omegaforl\\PyDSSP\\scripts\\pydssp"

def get_cypred_path():
    return "C:\\Users\\Rundead\\Novelfold\\Cypred\\CyPred.jar"  # Replace with the actual path

def get_cypred_input_path():
    return "C:\\Users\\Rundead\\path\\to\\input.fasta"  # Replace with the actual path
def get_cypred_output_path():
    return "C:\\Users\\Rundead\\path\\to\\output.cypred"  # Replace with the actual path

def get_archivelog_path():
    return "C:\\Users\\Rundead\\Novelfold\\Archive\\log.csv"